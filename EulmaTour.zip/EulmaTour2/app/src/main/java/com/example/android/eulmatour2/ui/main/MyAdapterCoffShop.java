package com.example.android.eulmatour2.ui.main;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.android.eulmatour2.R;

import java.util.ArrayList;

public class MyAdapterCoffShop extends BaseAdapter {

    Context context;
    ArrayList<CoffeeShop> arrListadapterCoffShop;

    public MyAdapterCoffShop(Context context, ArrayList<CoffeeShop> arrListadapterCoffShop) {
        this.context = context;
        this.arrListadapterCoffShop = arrListadapterCoffShop;


    }


    @Override


    public int getCount() {
        return arrListadapterCoffShop.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = LayoutInflater.from(context).inflate(R.layout.formlistview, viewGroup, false);
        TextView nameplace = view.findViewById(R.id.strclassname);
        TextView longitude = view.findViewById(R.id.strclasslongitude);
        TextView latitude = view.findViewById(R.id.strclasslatitude);
        //set data in the textview
        nameplace.setText(" " + arrListadapterCoffShop.get(position).mNameCoffeeShop);
        longitude.setText(arrListadapterCoffShop.get(position).mlongitude);
        latitude.setText(arrListadapterCoffShop.get(position).mlatitude);

        return view;
    }
}
