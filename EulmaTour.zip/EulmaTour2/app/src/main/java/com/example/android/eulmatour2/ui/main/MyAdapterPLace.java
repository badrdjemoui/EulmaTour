package com.example.android.eulmatour2.ui.main;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.android.eulmatour2.R;

import java.util.ArrayList;

public class MyAdapterPLace extends BaseAdapter {

    Context context;
    ArrayList<Place> arrListadapterPlace;
    int[] place;

    public MyAdapterPLace(Context context, ArrayList<Place> arrListadapterPlace, int[] place) {
        this.context = context;
        this.arrListadapterPlace = arrListadapterPlace;
        this.place = place;

    }


    @Override


    public int getCount() {
        return arrListadapterPlace.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = LayoutInflater.from(context).inflate(R.layout.formlistview, viewGroup, false);
        TextView nameplace = view.findViewById(R.id.strclassname);
        TextView longitude = view.findViewById(R.id.strclasslongitude);
        TextView latitude = view.findViewById(R.id.strclasslatitude);

        ImageView placeimage = view.findViewById(R.id.images_id);

        //set data in the textview

        nameplace.setText(" " + arrListadapterPlace.get(position).getnamePlace());
        longitude.setText(arrListadapterPlace.get(position).getlongitude());
        latitude.setText(arrListadapterPlace.get(position).mlatitude);

        placeimage.setImageResource(place[position]);


        return view;
    }
}
