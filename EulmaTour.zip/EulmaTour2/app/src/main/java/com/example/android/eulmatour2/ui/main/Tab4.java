package com.example.android.eulmatour2.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.android.eulmatour2.R;

import java.util.ArrayList;

public class Tab4 extends Fragment {
    ListView listView;
    // create array list

    ArrayList<Restaurant> arrayListRestaurant ;


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab4, container, false);
        //
        listView = view.findViewById(R.id.listview4);

        // Checking of arrayListRestaurant is not null
        if(arrayListRestaurant != null) {
            arrayListRestaurant.clear();
        } else {
            arrayListRestaurant = new ArrayList<>();
        }
        // add data

        arrayListRestaurant.add(new Restaurant("kadour", "36.692408", "7.429908"));
        arrayListRestaurant.add(new Restaurant("Samir", "36.722454", "7.356926"));
        arrayListRestaurant.add(new Restaurant("salah", "36.787774", "7.499426"));

        //call MyAdapter

        MyAdapterRestaurant myAdapterPlace = new MyAdapterRestaurant(getActivity(), arrayListRestaurant);
        listView.setAdapter(myAdapterPlace);

        return view;

    }

}
