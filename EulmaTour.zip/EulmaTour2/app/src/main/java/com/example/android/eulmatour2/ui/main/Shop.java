package com.example.android.eulmatour2.ui.main;

public class Shop {
    final String mNameShop;
    final String mlongitude;
    final String mlatitude;

    public Shop(String mNameShop, String mlongitude, String mlatitude) {
        this.mNameShop = mNameShop;
        this.mlongitude = mlongitude;
        this.mlatitude = mlatitude;
    }

    public String getmNameShop() {
        return mNameShop;
    }

    public String getMlongitude() {
        return mlongitude;
    }

    public String getMlatitude() {
        return mlatitude;
    }
}
