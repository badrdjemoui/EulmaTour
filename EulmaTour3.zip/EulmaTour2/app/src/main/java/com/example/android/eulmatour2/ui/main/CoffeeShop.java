package com.example.android.eulmatour2.ui.main;

public class CoffeeShop {
    final String mNameCoffeeShop;
    final String mlongitude;
    final String mlatitude;

    public CoffeeShop(String mNameCoffeeShop, String mlongitude, String mlatitude) {
        this.mNameCoffeeShop = mNameCoffeeShop;
        this.mlongitude = mlongitude;
        this.mlatitude = mlatitude;
    }

    public String getmNameCoffeeShop() {
        return mNameCoffeeShop;
    }

    public String getMlongitude() {
        return mlongitude;
    }

    public String getMlatitude() {
        return mlatitude;
    }
}
