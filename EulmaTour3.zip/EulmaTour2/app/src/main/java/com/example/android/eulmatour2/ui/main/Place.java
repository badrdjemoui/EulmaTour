package com.example.android.eulmatour2.ui.main;

public class Place {
    final String mNamePlace;
    final String mlongitude;
    final String mlatitude;


    public Place(String mNamePlace, String mlongitude, String mlatitude) {
        this.mNamePlace = mNamePlace;
        this.mlongitude = mlongitude;
        this.mlatitude = mlatitude;
    }

    public String getnamePlace() {
        return mNamePlace;

    }

    public String getlongitude() {
        return mlongitude;

    }


}
