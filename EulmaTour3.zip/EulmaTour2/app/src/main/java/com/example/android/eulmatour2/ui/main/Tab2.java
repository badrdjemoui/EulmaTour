package com.example.android.eulmatour2.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.android.eulmatour2.R;

import java.util.ArrayList;

public class Tab2 extends Fragment {

    ListView listView;
    // create array list

    ArrayList<Shop> arrayListShop ;


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab2, container, false);
        //
        listView = view.findViewById(R.id.listview2);

        // Checking of arrayListShop is not null
        if(arrayListShop != null) {
            arrayListShop.clear();
        } else {
            arrayListShop = new ArrayList<>();
        }

        // add data
        arrayListShop.add(new Shop("nouari", "36.692408", "7.429908"));
        arrayListShop.add(new Shop("lola", "36.722454", "7.356926"));
        arrayListShop.add(new Shop("azzou", "36.787774", "7.499426"));


        //call MyAdapter

        MyAdapterShop myAdapterPlace = new MyAdapterShop(getActivity(), arrayListShop);
        listView.setAdapter(myAdapterPlace);

        return view;

    }


}
