package com.example.android.eulmatour2.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.android.eulmatour2.R;

import java.util.ArrayList;

public class Tab3 extends Fragment {
    ListView listView;
    // create array list

    ArrayList<CoffeeShop> arrayListCoffShop ;


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab3, container, false);
        //
        listView = view.findViewById(R.id.listview3);


        // Checking of arrayListCoffShop is not null
        if(arrayListCoffShop != null) {
            arrayListCoffShop.clear();
        } else {
            arrayListCoffShop = new ArrayList<>();
        }
        // add data

        arrayListCoffShop.add(new CoffeeShop("kadour", "36.692408", "7.429908"));
        arrayListCoffShop.add(new CoffeeShop("Samir", "36.722454", "7.356926"));
        arrayListCoffShop.add(new CoffeeShop("salah", "36.787774", "7.499426"));


        //call MyAdapter

        MyAdapterCoffShop myAdapterPlace = new MyAdapterCoffShop(getActivity(), arrayListCoffShop);
        listView.setAdapter(myAdapterPlace);

        return view;

    }


}
