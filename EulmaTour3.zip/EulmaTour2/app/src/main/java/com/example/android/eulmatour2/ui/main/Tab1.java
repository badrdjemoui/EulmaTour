package com.example.android.eulmatour2.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.android.eulmatour2.R;

import java.util.ArrayList;

public class Tab1 extends Fragment {

    ListView listView;
    // create array int for images
    int[] placesIMG = {R.drawable.e7, R.drawable.e8, R.drawable.e9, R.drawable.e7, R.drawable.e8, R.drawable.e9, R.drawable.e7, R.drawable.e8, R.drawable.e9};

    // create array list

    ArrayList<Place> arrayList;
// Checking of movieList is not null


    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab1, container, false);
        //

        listView = view.findViewById(R.id.listview1);
        // Checking of arrayList is not null

        if (arrayList != null) {
            arrayList.clear();
        } else {
            arrayList = new ArrayList<>();
        }
        // add data
        arrayList.add(new Place("oued elhout", "36.692408", "7.429908"));
        arrayList.add(new Place("east west road ", "36.789274", "7.509046"));
        arrayList.add(new Place("lac Fetzara", "36.758543", "7.499090"));


        //call MyAdapter

        MyAdapterPLace myAdapterPlace = new MyAdapterPLace(getActivity(), arrayList, placesIMG);
        listView.setAdapter(myAdapterPlace);

        return view;

    }
}
